#!/usr/bin/env python3
"""
retune_all.py - re-run tune_ctx.py for every model listed in models.conf.

Use this any time your VRAM situation changes (GPU added, removed, or a
card fails) to re-discover the 100%-GPU context ceiling for every tracked
model and rebuild them under fresh, honestly-labeled tags.

Usage:
    python retune_all.py [--config models.conf]

Reads models.conf in the same directory as this script by default. Add or
edit lines there (format: Modelfile|name_prefix|max_ctx|required_ctx) to
change what gets tuned. required_ctx is optional -- see tune_ctx.py's
--required-ctx for what it does.

Identical behavior on Windows, Linux, and macOS -- this is the single
canonical version. models.conf itself is machine-specific (each rig has
its own Modelfile names/paths and its own VRAM-driven max_ctx/required_ctx
values), but the script that reads it is exactly the same file everywhere.
"""
import argparse
import subprocess
import sys
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("-c", "--config", default="models.conf", help="Path to the registry file")
    args = p.parse_args()

    script_dir = Path(__file__).resolve().parent
    conf_path = Path(args.config)
    if not conf_path.is_absolute():
        conf_path = script_dir / conf_path
    if not conf_path.is_file():
        print(f"ERROR: missing {conf_path}", file=sys.stderr)
        sys.exit(1)

    tune_script = script_dir / "tune_ctx.py"
    if not tune_script.is_file():
        print(f"ERROR: tune_ctx.py not found next to this script ({tune_script})", file=sys.stderr)
        sys.exit(1)

    any_failed = False

    for raw_line in conf_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = [x.strip() for x in line.split("|")]
        if len(parts) < 3:
            print(f"WARNING: skipping malformed line: {line}", file=sys.stderr)
            continue
        modelfile, prefix, max_ctx = parts[0], parts[1], parts[2]
        required_ctx = parts[3] if len(parts) > 3 and parts[3] else None

        print()
        print("############################################################")
        print(f"# Retuning: {prefix}")
        print(f"#   Modelfile:    {modelfile}")
        print(f"#   max_ctx:      {max_ctx}")
        print(f"#   required_ctx: {required_ctx or 'none'}")
        print("############################################################")

        cmd = [
            sys.executable, str(tune_script),
            "-f", modelfile,
            "-n", prefix,
            "-x", max_ctx,
        ]
        if required_ctx:
            cmd += ["-r", required_ctx]

        result = subprocess.run(cmd)
        if result.returncode != 0:
            any_failed = True
            print(f"WARNING: tune_ctx.py failed for {prefix} (exit {result.returncode})", file=sys.stderr)

    print()
    print("== All models retuned. Current inventory: ==")
    subprocess.run(["ollama", "list"])

    if any_failed:
        sys.exit(1)


if __name__ == "__main__":
    main()

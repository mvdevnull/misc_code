#!/usr/bin/env python3
"""
tune_ctx.py - binary-search the largest num_ctx that fits 100% on GPU for a
given ollama Modelfile, then build and name the production model.

Cross-platform (Windows/Linux/macOS) - works anywhere Python 3.7+ and
ollama are both on PATH. Same logic as before: test a low ctx (should
fit), test a high ctx (may not fit), binary-search between them for the
exact wall, subtract a safety margin, then build the final model and
rename it to "<prefix>-<ctx>k-<toks>toks" using the REAL measured tok/s.

If the model's static weight footprint is bigger than total VRAM, no
context size will ever hit 100% GPU. The script detects this and just
builds at whatever ctx you passed via --max-ctx, reporting the real
CPU/GPU split honestly instead of pretending a fix was found.

Benchmark prompt: every load/measure cycle asks the model to count to 250
rather than just "hi" -- a one-word reply finishes fast enough that
eval_count/eval_duration timing noise can produce nonsense tok/s readings
(500+ tok/s on models that are structurally incapable of that). The longer,
deterministic reply keeps the measurement stable. If a reply still comes
back short (e.g. the model refuses or truncates), the console output flags
it as [LOW CONFIDENCE] rather than silently baking a bad number into the
model's name.

Usage:
    python tune_ctx.py -f Modelfile.qwen3.6-27b -n PT-qwen3.6-27b-q4km
    python tune_ctx.py -f Modelfile.qwen3.5-122b-a10b-50k -n PT-qwen3.5-122b-a10b-q4km -x 50000

Options:
    -f, --modelfile    Path to the Modelfile to tune (edited in place)
    -n, --name-prefix  Final model name prefix, WITHOUT ctx/toks suffix
                        e.g. PT-qwen3.6-27b-q4km -> produces PT-qwen3.6-27b-q4km-51k-21toks
    -x, --max-ctx       Max context to try (default 200000). This is a CEILING —
                        the search never tries anything above it, and it never
                        auto-expands if VRAM increases later; raise it manually.
    -m, --min-ctx       Min context floor assumed to fit at 100% GPU (default 2048).
                        This is a SEARCH parameter, not a guarantee about the final
                        production context -- see --required-ctx for that. NOTE: if
                        --required-ctx is higher than this, the search floor is raised
                        to --required-ctx automatically -- nothing below your required
                        floor is ever tested.
    -s, --step          Search resolution / binary-search stop granularity (default 1024)
    -g, --margin        Safety margin subtracted from the found ceiling (default: 2 * step)
    -r, --required-ctx  Required production context -- a hard FLOOR on what actually
                        gets built, independent of the search. Also raises the search's
                        own lower bound: if --required-ctx is above --min-ctx, the
                        search never tests anything below --required-ctx either -- no
                        point probing contexts you'd reject at the end anyway. If
                        ceiling-minus-margin (or the no-fit fallback) still computes a
                        production ctx below this, it's overridden up to here instead,
                        accepting whatever CPU/GPU split results. Use this to guarantee
                        "I always need at least N" even when a VRAM regression would
                        otherwise shrink the found ceiling below what you need. Unset
                        by default.
    -d, --dry-run       Only search, don't build/rename the production model

Requires: ollama on PATH, Python 3.7+. Identical behavior on Windows, Linux,
and macOS -- this is the single canonical version, there is no separate
bash/PowerShell variant to keep in sync.
"""
import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

# A short prompt like "hi" produces a tiny reply, and dividing a small token
# count by a near-zero duration produces wildly inflated (and meaningless)
# tok/s readings -- e.g. 547, 693, 908 tok/s on models that are structurally
# incapable of running anywhere near that fast. Forcing a long, deterministic
# reply keeps eval_count/eval_duration big enough for the ratio to be stable.
BENCH_PROMPT = "Count from 1 to 250, one number per line. Output only the numbers, nothing else."
MIN_RELIABLE_EVAL_COUNT = 30


def run(cmd):
    """Run a subprocess, returning CompletedProcess with decoded text output.
    Exits with a clear message if the executable itself can't be found
    (e.g. ollama disappeared from PATH mid-run) rather than a raw traceback."""
    try:
        return subprocess.run(
            cmd, capture_output=True, text=True, encoding="utf-8", errors="replace"
        )
    except FileNotFoundError:
        print(f"ERROR: '{cmd[0]}' not found on PATH. Is ollama installed and available?", file=sys.stderr)
        sys.exit(1)


def set_ctx(modelfile: Path, ctx: int) -> None:
    text = modelfile.read_text(encoding="utf-8")
    new_text, n = re.subn(
        r"^PARAMETER num_ctx .*$", f"PARAMETER num_ctx {ctx}", text, flags=re.MULTILINE
    )
    if n == 0:
        raise RuntimeError(f"No 'PARAMETER num_ctx' line found in {modelfile}")
    modelfile.write_text(new_text, encoding="utf-8")


def ollama_list():
    return run(["ollama", "list"]).stdout.splitlines()


def ollama_ps():
    return run(["ollama", "ps"]).stdout.splitlines()


def parse_gpu_pct(ps_line: str) -> int:
    if "100% GPU" in ps_line:
        return 100
    m = re.search(r"(\d+)%/(\d+)%\s+CPU/GPU", ps_line)
    return int(m.group(2)) if m else 0


def parse_eval_rate(run_output: str) -> float:
    # ollama's --verbose output has TWO "eval rate:" lines -- "prompt eval
    # rate:" (prefill speed, fast, not what we want) and "eval rate:"
    # (generation speed, what we want). Since "prompt eval rate:" literally
    # CONTAINS the substring "eval rate:", a naive search matches the wrong
    # one (it comes first in the output). The negative lookbehind rejects
    # any match immediately preceded by "prompt ".
    m = re.search(r"(?<!prompt )eval rate:\s+([0-9]+\.[0-9]+)\s+tokens/s", run_output)
    return float(m.group(1)) if m else 0.0


def parse_eval_count(run_output: str) -> int:
    # Same trap as parse_eval_rate: "prompt eval count:" contains "eval
    # count:" as a substring and would otherwise match first.
    m = re.search(r"(?<!prompt )eval count:\s+(\d+)\s+token", run_output)
    return int(m.group(1)) if m else 0


def test_ctx(modelfile: Path, tune_tag: str, ctx: int):
    """Build, load, measure, tear down a throwaway model at this ctx.
    Returns (gpu_pct, eval_rate)."""
    tag = f"{tune_tag}-{ctx}"
    set_ctx(modelfile, ctx)

    create = run(["ollama", "create", tag, "-f", str(modelfile)])
    if create.returncode != 0:
        print(f"  ERROR: ollama create failed for ctx={ctx}:\n{create.stderr}", file=sys.stderr)
        return 0, 0.0

    run_result = run(["ollama", "run", tag, BENCH_PROMPT, "--verbose"])
    run_output = (run_result.stdout or "") + (run_result.stderr or "")

    ps_line = next((l for l in ollama_ps() if l.startswith(f"{tag}:")), "")

    run(["ollama", "stop", tag])
    run(["ollama", "rm", tag])

    if not ps_line:
        print(f"  WARNING: could not read ollama ps for ctx={ctx} (load may have failed)", file=sys.stderr)
        return 0, 0.0

    gpu_pct = parse_gpu_pct(ps_line)
    eval_rate = parse_eval_rate(run_output)
    eval_count = parse_eval_count(run_output)
    reliability = "" if eval_count >= MIN_RELIABLE_EVAL_COUNT else "  [LOW CONFIDENCE: short reply, timing noise]"
    print(f"  ctx={ctx}  gpu={gpu_pct}%  eval_rate={eval_rate} tok/s (n={eval_count}){reliability}   ({ps_line.strip()})")
    return gpu_pct, eval_rate


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("-f", "--modelfile", required=True, help="Path to the Modelfile to tune (edited in place)")
    p.add_argument("-n", "--name-prefix", required=True, help="Final model name prefix, e.g. PT-qwen3.6-27b-q4km")
    p.add_argument("-x", "--max-ctx", type=int, default=200000, help="Max context to try (default 200000)")
    p.add_argument("-m", "--min-ctx", type=int, default=2048, help="Min context floor assumed to fit (default 2048)")
    p.add_argument("-s", "--step", type=int, default=1024, help="Search resolution in tokens (default 1024)")
    p.add_argument("-g", "--margin", type=int, default=None, help="Safety margin subtracted from ceiling (default: 2 * step)")
    p.add_argument("-r", "--required-ctx", type=int, default=None, help="Hard floor on production ctx, overrides a too-small search result")
    p.add_argument("-d", "--dry-run", action="store_true", help="Only search, don't build/rename the production model")
    args = p.parse_args()

    if shutil.which("ollama") is None:
        print("ERROR: 'ollama' not found on PATH. Install it or fix your PATH before running this.", file=sys.stderr)
        sys.exit(1)

    modelfile = Path(args.modelfile)
    if not modelfile.is_file():
        print(f"ERROR: Modelfile not found: {modelfile}", file=sys.stderr)
        sys.exit(1)

    if args.step < 1:
        print("ERROR: --step must be >= 1", file=sys.stderr)
        sys.exit(1)
    if args.min_ctx < 1:
        print("ERROR: --min-ctx must be >= 1", file=sys.stderr)
        sys.exit(1)
    if args.max_ctx <= args.min_ctx:
        print(f"ERROR: --max-ctx ({args.max_ctx}) must be greater than --min-ctx ({args.min_ctx})", file=sys.stderr)
        sys.exit(1)
    if args.margin is not None and args.margin < 0:
        print("ERROR: --margin must be >= 0", file=sys.stderr)
        sys.exit(1)
    if args.required_ctx is not None and args.required_ctx < 1:
        print("ERROR: --required-ctx must be >= 1", file=sys.stderr)
        sys.exit(1)

    # A required_ctx above min_ctx also raises the search's own floor -- there's no
    # point spending a full load/benchmark/teardown cycle probing a context you've
    # already said you'll never accept. min_floor_is_required records *why* the
    # floor is where it is, so the "doesn't fit" branch below can react correctly:
    # a plain --min-ctx floor failing means true no-fit (fall back to max_ctx), but
    # a required_ctx floor failing just means "build at required_ctx anyway and
    # accept the split" -- falling back to max_ctx there would be strictly worse.
    min_floor_is_required = args.required_ctx is not None and args.required_ctx > args.min_ctx
    effective_min = args.required_ctx if min_floor_is_required else args.min_ctx

    if args.max_ctx <= effective_min:
        label = "--required-ctx" if min_floor_is_required else "--min-ctx"
        print(f"ERROR: --max-ctx ({args.max_ctx}) must be greater than {label} ({effective_min})", file=sys.stderr)
        sys.exit(1)

    margin = args.margin if args.margin is not None else args.step * 2
    tune_tag = f"{args.name_prefix}-tune"

    print("== tune_ctx.py ==")
    print(f"Modelfile:    {modelfile}")
    print(f"Name prefix:  {args.name_prefix}")
    range_note = "  (floor raised to required_ctx)" if min_floor_is_required else ""
    print(f"Search range: [{effective_min} .. {args.max_ctx}], resolution {args.step}, margin {margin}{range_note}")
    print()

    no_fit = False

    print(f"-- checking upper bound (max ctx = {args.max_ctx}) --")
    gpu_pct, _ = test_ctx(modelfile, tune_tag, args.max_ctx)
    if gpu_pct == 100:
        print(f"Max ctx ({args.max_ctx}) already fits 100% on GPU. Raise -x if you want to search higher.")
        ceiling = args.max_ctx
    else:
        print()
        floor_label = "required ctx floor" if min_floor_is_required else "min ctx"
        print(f"-- checking lower bound ({floor_label} = {effective_min}) --")
        gpu_pct, _ = test_ctx(modelfile, tune_tag, effective_min)
        if gpu_pct < 100:
            print()
            if min_floor_is_required:
                print(f"Your required ctx floor (ctx={effective_min}) does not fit 100% on GPU.")
                print(f"Building at {effective_min} anyway -- it's a hard requirement, so accepting")
                print("whatever CPU/GPU split results rather than falling back to a bigger ctx")
                print("(max_ctx) that would only make the split worse for no benefit.")
                no_fit = True
                ceiling = effective_min
            else:
                print(f"Even the floor (ctx={effective_min}) does not fit 100% on GPU.")
                print("This model's static weight footprint is likely bigger than your total VRAM --")
                print("no context size will reach 100% GPU on this hardware. Building at your")
                print(f"requested -x value ({args.max_ctx}) instead of shrinking further, since that won't help.")
                no_fit = True
                ceiling = args.max_ctx
        else:
            print()
            print(f"-- binary search between {effective_min} (fits) and {args.max_ctx} (doesn't fit) --")
            lo, hi = effective_min, args.max_ctx
            while hi - lo > args.step:
                mid = (lo + hi) // 2
                mid = (mid // args.step) * args.step
                if mid <= lo:
                    mid = lo + args.step
                if mid >= hi:
                    break
                gpu_pct, _ = test_ctx(modelfile, tune_tag, mid)
                if gpu_pct == 100:
                    lo = mid
                else:
                    hi = mid
            ceiling = lo

    print()
    print("== RESULT ==")
    if no_fit:
        final_ctx = ceiling
        print("No context size reaches 100% GPU on this hardware.")
        source = "your required -r floor" if min_floor_is_required else "your requested -x value"
        print(f"Production ctx: {final_ctx} ({source}, real split reported below)")
    else:
        print(f"Largest ctx at 100% GPU: {ceiling}")
        final_ctx = ceiling - margin
        if final_ctx < effective_min:
            final_ctx = effective_min
        print(f"Applying safety margin of {margin} -> production ctx: {final_ctx}")

    if args.required_ctx is not None and final_ctx < args.required_ctx:
        print()
        print(f"NOTE: computed production ctx ({final_ctx}) is below your required floor ({args.required_ctx}).")
        print(f"Overriding to {args.required_ctx} -- accepting whatever CPU/GPU split results, since you")
        print("need at least this much context for the model to be usable.")
        final_ctx = args.required_ctx

    if args.dry_run:
        print(f"Dry run: leaving Modelfile set to ctx={final_ctx}, skipping production build.")
        set_ctx(modelfile, final_ctx)
        return

    # Remove any previous production tag(s) for this prefix before installing the new
    # one, so re-running after a hardware change doesn't leave stale entries behind.
    old_tags = [
        line.split()[0]
        for line in ollama_list()[1:]
        if line.startswith(f"{args.name_prefix}-")
    ]
    if old_tags:
        print()
        print("Removing previous production tag(s) for this prefix:")
        for t in old_tags:
            print(f"  {t}")
            run(["ollama", "rm", t])

    print()
    print(f"-- building production model at ctx={final_ctx} --")
    set_ctx(modelfile, final_ctx)
    tmp_tag = f"{args.name_prefix}-ctx{final_ctx}-tmp"
    create = run(["ollama", "create", tmp_tag, "-f", str(modelfile)])
    if create.returncode != 0:
        print(f"ERROR: final ollama create failed:\n{create.stderr}", file=sys.stderr)
        sys.exit(1)

    run_result = run(["ollama", "run", tmp_tag, BENCH_PROMPT, "--verbose"])
    run_output = (run_result.stdout or "") + (run_result.stderr or "")
    print("--- ollama ps (final, real split) ---")
    print("\n".join(ollama_ps()))

    final_rate = parse_eval_rate(run_output)
    final_count = parse_eval_count(run_output)
    if final_count < MIN_RELIABLE_EVAL_COUNT:
        print(f"WARNING: final benchmark reply was only {final_count} tokens -- the tok/s in the name below may be unreliable.")
    final_rate_int = int(final_rate)  # truncate, matches the bash/PowerShell versions
    ctx_label = f"{final_ctx // 1000}k"
    final_name = f"{args.name_prefix}-{ctx_label}-{final_rate_int}toks"

    cp = run(["ollama", "cp", tmp_tag, final_name])
    print(cp.stdout.strip())
    run(["ollama", "rm", tmp_tag])

    print()
    print("== DONE ==")
    print(f"Production model: {final_name}")
    for line in ollama_list():
        if final_name in line:
            print(line)


if __name__ == "__main__":
    main()
